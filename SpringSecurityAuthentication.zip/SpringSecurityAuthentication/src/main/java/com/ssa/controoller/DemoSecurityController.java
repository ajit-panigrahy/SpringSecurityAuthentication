package com.ssa.controoller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DemoSecurityController {
	@ResponseBody
	@GetMapping("/")
	public String demoMsg() {
		return "general audeinece";
	}
	@ResponseBody
	@GetMapping("/access1")
	public String request1() {
		return "This is admin page";
	}
	@ResponseBody
	@GetMapping("/access2")
	public String request2() {
		return "This is user page";
	}
	@ResponseBody
	@GetMapping("/access3")
	public String request3() {
		return "This is both user and admin page";
	}
}