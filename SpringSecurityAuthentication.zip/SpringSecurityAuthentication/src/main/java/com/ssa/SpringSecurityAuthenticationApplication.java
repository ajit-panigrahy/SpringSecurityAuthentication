package com.ssa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAuthenticationApplication.class,
				args);
		System.out.println("Application Started............");
	}

}
